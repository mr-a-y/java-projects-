import java.rmi.registry.LocateRegistry; 
import java.rmi.registry.Registry; 
import java.io.*;

public class ClientRMI{

      public static void main(String[] args) {
      ...



         System.out.println("upper:\t" + ..);
         System.out.println("sort:\t" +  ...);
         System.out.println("rever:\t" + ...);
         System.out.println("isPanl:\t" + ...);
  }
}
