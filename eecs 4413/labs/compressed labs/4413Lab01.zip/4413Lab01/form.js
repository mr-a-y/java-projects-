// put your JS functions here

function ....  // validate various form components{
	

function ....   // change logo
function ....   // change background
function ...
   
 