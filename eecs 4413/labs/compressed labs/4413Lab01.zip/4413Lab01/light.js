/* 4413 23f Task 1 - write your code here */

function lightOn (){

 /* set image src to be that for light 1, and set message texts to be "light #1 is on"  */
 
  
}

 