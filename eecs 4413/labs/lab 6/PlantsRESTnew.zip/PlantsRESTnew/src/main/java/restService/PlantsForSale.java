package restService;

import java.util.HashMap;

//import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

//this class is a simple implementation of a REST service
//it is the simplest Plant catalog,

@Path("Plants") // this is the path of the service
public class PlantsForSale {

	Catalog catalog;

	public PlantsForSale() {
		
		System.out.println("call 4Sale constructor");
		catalog = new Catalog();
		
		/*try {
			// catalog is a singleton, shared among all customers
			catalog = Catalog.getInstance();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
*/
	}

	/* GET Plants */
	// return the collection of plants as JSON

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public HashMap<String, Plant> getPlantsNames() {
		return catalog.getCatalog();
		//return Response.status(200).entity(content).build();

	}

	/* GET Plants/{id} */
	// this is a READ method on the service
	// the resource name is plants, is a collection,
	// once you deploy this, you can access this method with
	// the url is http://localhost:8080/SampleStore/rest/Plants

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Plant getPrice(@DefaultValue("rose") @PathParam("id") String id) {
		Plant content = catalog.getPlant(id);
		return content;
	}

	/* POST plants */
	// this is a CREATE method on the service
	// the resource name is plant, the operation is POST, the parameters are passed
	// as
	// parameters in a form/query/path
	// once you deploy this, you can access this method with
	// http://localhost:8080/SampleStore/rest/Plants?id={1d}...
	// you can invoke it at the above address but need to include the parameters


	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	public HashMap<String, Plant> createPlant(@QueryParam("id") String id, @QueryParam("plantName") String name, @QueryParam("price") double price, @DefaultValue("default desc") @QueryParam("desc") String desc) {
		System.out.println("received:" + name + " " + price);
		catalog.put(id, name, price, desc);
		return catalog.getCatalog();
		//return Response.status(200).entity(content).build();
	}
	

	/* to be completed */
	public void deletePlant(String name) {
		catalog.remove(name);

	}

	/* to be completed */
	public void updatePlant(String name, String price) {
		catalog.replace(name, price);
	}

}
